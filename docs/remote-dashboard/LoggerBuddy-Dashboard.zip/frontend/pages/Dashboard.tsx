import { useState, useEffect, useMemo } from 'react'
import { useGetLogs, useDeleteLog, useDeleteAllLogs } from '../hooks/backend/logs'
import { toast } from 'sonner'
import { Toaster } from '../lib/shadcn/sonner'
import { Button } from '../lib/shadcn/button'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '../lib/shadcn/alert-dialog'
import {
  RefreshCw,
  Trash2,
  Download,
  Bug,
  AlertCircle,
  Layers,
} from 'lucide-react'
import type { Log } from './types'
import StatsCards from './ui/StatsCards'
import LogFilters, { type FilterState } from './ui/LogFilters'
import LogsTable from './ui/LogsTable'
import LogDetail from './ui/LogDetail'
import LogCharts from './ui/LogCharts'

const DEFAULT_FILTERS: FilterState = {
  search: '',
  levels: [],
  crashesOnly: false,
  datePreset: 'all',
  dateFrom: '',
  dateTo: '',
}

function getDateRange(f: FilterState): { from: Date | null; to: Date | null } {
  const now = new Date()
  if (f.datePreset === 'today') {
    return {
      from: new Date(now.getFullYear(), now.getMonth(), now.getDate()),
      to: new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999),
    }
  }
  if (f.datePreset === 'last24h') {
    return { from: new Date(now.getTime() - 24 * 60 * 60 * 1000), to: null }
  }
  if (f.datePreset === 'last7d') {
    return { from: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000), to: null }
  }
  if (f.datePreset === 'last30d') {
    return { from: new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000), to: null }
  }
  if (f.datePreset === 'custom') {
    return {
      from: f.dateFrom ? new Date(f.dateFrom + 'T00:00:00') : null,
      to: f.dateTo ? new Date(f.dateTo + 'T23:59:59.999') : null,
    }
  }
  return { from: null, to: null }
}

function applyFilters(logs: Log[], f: FilterState): Log[] {
  const { from, to } = getDateRange(f)

  return logs.filter((log) => {
    // Multi-level filter (empty = show all)
    if (f.levels.length > 0 && !f.levels.includes(log.level ?? '')) return false

    // Crashes only
    if (f.crashesOnly && !log.is_crash) return false

    // Full-text search
    if (f.search) {
      const q = f.search.toLowerCase()
      const fields = [log.message, log.tag, log.device_model, log.session_id, log.stack_trace]
      if (!fields.some((s) => s?.toLowerCase().includes(q))) return false
    }

    // Date range
    if (from || to) {
      const logDate = log.timestamp ? new Date(log.timestamp) : null
      if (!logDate) return false
      if (from && logDate < from) return false
      if (to && logDate > to) return false
    }

    return true
  })
}

export default function Dashboard() {
  const { data: rawLogs, loading, error, trigger: fetchLogs } = useGetLogs()
  const { trigger: deleteOneFn, loading: deletingOne } = useDeleteLog()
  const { trigger: deleteAllFn, loading: deletingAll } = useDeleteAllLogs()

  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTERS)
  const [selectedLog, setSelectedLog] = useState<Log | null>(null)

  // Initial load
  useEffect(() => {
    fetchLogs()
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const logs = useMemo<Log[]>(() => {
    if (!rawLogs) return []
    return rawLogs as Log[]
  }, [rawLogs])

  const filteredLogs = useMemo(() => applyFilters(logs, filters), [logs, filters])

  const isFiltered =
    filters.search !== '' ||
    filters.levels.length > 0 ||
    filters.crashesOnly ||
    filters.datePreset !== 'all'

  async function handleRefresh() {
    await fetchLogs(undefined, { skipCache: true })
    toast.success('Logs refreshed')
  }

  async function handleDeleteSelected() {
    if (!selectedLog) return
    try {
      await deleteOneFn({ id: selectedLog.id })
      setSelectedLog(null)
      await fetchLogs(undefined, { skipCache: true })
      toast.success('Log entry deleted')
    } catch {
      toast.error('Failed to delete log')
    }
  }

  async function handleDeleteAll() {
    try {
      await deleteAllFn()
      setSelectedLog(null)
      setFilters(DEFAULT_FILTERS)
      await fetchLogs(undefined, { skipCache: true })
      toast.success('All logs deleted')
    } catch {
      toast.error('Failed to delete logs')
    }
  }

  function handleExport() {
    const json = JSON.stringify(filteredLogs, null, 2)
    const blob = new Blob([json], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `loggerbuddy-export-${new Date().toISOString().slice(0, 10)}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    toast.success(`Exported ${filteredLogs.length} logs as JSON`)
  }

  const busy = loading || deletingOne || deletingAll

  return (
    <div className="min-h-screen bg-[#0d1117] text-white font-sans">
      <Toaster position="top-right" theme="dark" richColors />

      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 py-6 space-y-5">

        {/* ── 1. Header ────────────────────────────────────── */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-500/15 rounded-xl border border-blue-500/20">
              <Bug className="w-6 h-6 text-blue-400" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white tracking-tight">
                LoggerBuddy Dashboard
              </h1>
              <p className="text-xs text-gray-500 mt-0.5">
                Remote Android logs and crash monitoring
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {loading && (
              <span className="text-xs text-gray-500 flex items-center gap-1">
                <RefreshCw className="w-3 h-3 animate-spin" />
                Loading…
              </span>
            )}
            <Button
              onClick={handleRefresh}
              disabled={busy}
              size="sm"
              className="bg-blue-600 hover:bg-blue-700 text-white border-0 gap-2 h-8"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </div>

        {/* ── 2. Stats cards ───────────────────────────────── */}
        <StatsCards filteredLogs={filteredLogs} />

        {/* ── 3. Analytics charts ──────────────────────────── */}
        <div>
          <p className="text-[10px] font-semibold text-gray-600 uppercase tracking-widest mb-3">
            Analytics
          </p>
          <LogCharts logs={filteredLogs} />
        </div>

        {/* ── 4. Filters & Actions ─────────────────────────── */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-4 space-y-3">
          <LogFilters filters={filters} onChange={setFilters} />

          {/* Actions bar */}
          <div className="flex flex-wrap items-center gap-2 pt-3 border-t border-gray-800">
            <span className="text-[10px] font-semibold text-gray-600 uppercase tracking-widest">
              Actions
            </span>

            <Button
              variant="ghost"
              size="sm"
              onClick={handleDeleteSelected}
              disabled={!selectedLog || deletingOne}
              className="h-7 text-xs text-red-400 hover:text-red-300 hover:bg-red-400/10 gap-1.5 disabled:opacity-30"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Delete Selected
            </Button>

            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  disabled={deletingAll || logs.length === 0}
                  className="h-7 text-xs text-red-400 hover:text-red-300 hover:bg-red-400/10 gap-1.5 disabled:opacity-30"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Delete All Logs
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent className="bg-gray-900 border-gray-700 text-white">
                <AlertDialogHeader>
                  <AlertDialogTitle className="text-white">
                    Delete All Logs?
                  </AlertDialogTitle>
                  <AlertDialogDescription className="text-gray-400">
                    This will permanently remove all{' '}
                    <span className="text-white font-semibold">{logs.length}</span> log
                    {logs.length !== 1 ? 's' : ''} from the database. This action
                    cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel className="bg-gray-800 border-gray-700 text-gray-200 hover:bg-gray-700 hover:text-white">
                    Cancel
                  </AlertDialogCancel>
                  <AlertDialogAction
                    onClick={handleDeleteAll}
                    className="bg-red-600 hover:bg-red-700 text-white border-0"
                  >
                    Delete All
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>

            <Button
              variant="ghost"
              size="sm"
              onClick={handleExport}
              disabled={filteredLogs.length === 0}
              className="h-7 text-xs text-emerald-400 hover:text-emerald-300 hover:bg-emerald-400/10 gap-1.5 disabled:opacity-30"
            >
              <Download className="w-3.5 h-3.5" />
              Export JSON ({filteredLogs.length})
            </Button>

            <Button
              variant="ghost"
              size="sm"
              onClick={handleRefresh}
              disabled={busy}
              className="h-7 text-xs text-blue-400 hover:text-blue-300 hover:bg-blue-400/10 gap-1.5 disabled:opacity-30"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              Refresh Logs
            </Button>
          </div>
        </div>

        {/* ── Error banner ─────────────────────────────────── */}
        {error && (
          <div className="flex items-center gap-2 text-red-400 bg-red-400/10 border border-red-500/20 rounded-xl px-4 py-3 text-sm">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* ── 5. Logs table + Detail panel ─────────────────── */}
        <div
          className={`grid gap-4 items-start ${
            selectedLog ? 'grid-cols-1 xl:grid-cols-[1fr_400px]' : 'grid-cols-1'
          }`}
        >
          {/* Table card */}
          <div className="bg-gray-900 rounded-xl border border-gray-800 p-4 flex flex-col gap-3 min-h-[480px]">
            <div className="flex items-center justify-between flex-shrink-0">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-gray-600" />
                <h2 className="text-sm font-semibold text-gray-200">Log Entries</h2>
                <span className="text-xs text-gray-600 font-mono">
                  {isFiltered
                    ? `${filteredLogs.length} / ${logs.length}`
                    : `${logs.length} total`}
                </span>
              </div>
              {selectedLog && (
                <span className="text-[10px] text-blue-400 bg-blue-400/10 border border-blue-500/20 px-2 py-1 rounded-full">
                  #{selectedLog.id} selected
                </span>
              )}
            </div>
            <div className="flex-1 min-h-0">
              {loading && logs.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-gray-600 gap-3 py-16">
                  <RefreshCw className="w-6 h-6 animate-spin text-blue-500" />
                  <span className="text-sm">Loading logs…</span>
                </div>
              ) : (
                <LogsTable
                  logs={filteredLogs}
                  selectedId={selectedLog?.id ?? null}
                  onSelect={setSelectedLog}
                />
              )}
            </div>
          </div>

          {/* ── 6. Selected log detail ───────────────────────── */}
          {selectedLog && (
            <LogDetail log={selectedLog} onClose={() => setSelectedLog(null)} />
          )}
        </div>

      </div>
    </div>
  )
}
