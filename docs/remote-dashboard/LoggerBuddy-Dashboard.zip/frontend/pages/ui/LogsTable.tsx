import { useMemo, useState } from 'react'
import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  getPaginationRowModel,
  flexRender,
  createColumnHelper,
  type SortingState,
} from '@tanstack/react-table'
import { ChevronUp, ChevronDown, ChevronsUpDown, ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from '../../lib/shadcn/button'
import { cn } from '../../lib/shadcn/utils'
import type { Log } from '../types'
import LevelBadge, { CrashBadge } from './LevelBadge'

type Props = {
  logs: Log[]
  selectedId: number | null
  onSelect: (log: Log) => void
}

const col = createColumnHelper<Log>()

function formatTime(ts: string): string {
  try {
    const d = new Date(ts)
    return d.toLocaleString(undefined, {
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    })
  } catch {
    return ts
  }
}

function SortIcon({ sorted }: { sorted: false | 'asc' | 'desc' }) {
  if (sorted === 'asc') return <ChevronUp className="w-3 h-3 text-blue-400" />
  if (sorted === 'desc') return <ChevronDown className="w-3 h-3 text-blue-400" />
  return <ChevronsUpDown className="w-3 h-3 opacity-30" />
}

export default function LogsTable({ logs, selectedId, onSelect }: Props) {
  const [sorting, setSorting] = useState<SortingState>([
    { id: 'timestamp', desc: true },
  ])

  const columns = useMemo(
    () => [
      col.accessor('timestamp', {
        header: 'Time',
        cell: (i) => (
          <span className="font-mono text-[11px] text-gray-400 whitespace-nowrap">
            {formatTime(i.getValue())}
          </span>
        ),
      }),
      col.accessor('level', {
        header: 'Level',
        cell: (i) => <LevelBadge level={i.getValue()} />,
      }),
      col.accessor('tag', {
        header: 'Tag',
        cell: (i) => (
          <span className="font-mono text-[11px] text-sky-400 whitespace-nowrap">
            {i.getValue() ?? '—'}
          </span>
        ),
      }),
      col.accessor('message', {
        header: 'Message',
        enableSorting: false,
        cell: (i) => {
          const raw = i.getValue()
          // For crash logs the message can be many lines — only show the first
          const firstLine = raw ? (raw.split('\n')[0] ?? '').trim() : ''
          const display = firstLine || '—'
          return (
            <span
              className="text-[12px] text-gray-300 whitespace-nowrap overflow-hidden text-ellipsis block max-w-[300px]"
              title={raw ?? undefined}
            >
              {display}
            </span>
          )
        },
      }),
      col.accessor('is_crash', {
        header: 'Crash',
        cell: (i) => <CrashBadge isCrash={i.getValue()} />,
      }),
      col.accessor('device_model', {
        header: 'Device',
        cell: (i) => (
          <span className="text-[11px] text-gray-400 whitespace-nowrap">
            {i.getValue() ?? '—'}
          </span>
        ),
      }),
      col.accessor('android_version', {
        header: 'Android',
        cell: (i) => (
          <span className="text-[11px] text-gray-500">
            {i.getValue() ? `v${i.getValue()}` : '—'}
          </span>
        ),
      }),
      col.accessor('app_version', {
        header: 'App Ver.',
        cell: (i) => (
          <span className="text-[11px] text-gray-500">{i.getValue() ?? '—'}</span>
        ),
      }),
    ],
    []
  )

  const table = useReactTable({
    data: logs,
    columns,
    state: { sorting },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    initialState: { pagination: { pageSize: 50 } },
  })

  const headerGroups = table.getHeaderGroups()
  const rows = table.getRowModel().rows

  return (
    <div className="flex flex-col gap-2 h-full">
      {/* Scrollable table */}
      <div className="flex-1 overflow-auto rounded-lg border border-gray-800 min-h-0">
        <table className="w-full border-collapse text-sm min-w-[700px]">
          <thead className="sticky top-0 z-10 bg-gray-900">
            {headerGroups.map((hg) => (
              <tr key={hg.id}>
                {hg.headers.map((header) => (
                  <th
                    key={header.id}
                    onClick={header.column.getToggleSortingHandler()}
                    className="text-left px-3 py-2.5 text-[10px] font-semibold text-gray-500 uppercase tracking-widest border-b border-gray-800 whitespace-nowrap select-none cursor-pointer hover:text-gray-300 transition-colors"
                  >
                    <div className="flex items-center gap-1">
                      {flexRender(header.column.columnDef.header, header.getContext())}
                      {header.column.getCanSort() && (
                        <SortIcon sorted={header.column.getIsSorted()} />
                      )}
                    </div>
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={8} className="text-center py-20 text-gray-600 text-sm">
                  No logs match the current filters
                </td>
              </tr>
            ) : (
              rows.map((row) => {
                const isSelected = row.original.id === selectedId
                const isCrash = Boolean(row.original.is_crash)
                return (
                  <tr
                    key={row.id}
                    onClick={() => onSelect(row.original)}
                    className={cn(
                      'border-b border-gray-800/50 cursor-pointer transition-colors duration-100',
                      isSelected
                        ? 'bg-blue-500/10 border-l-2 border-l-blue-500'
                        : isCrash
                        ? 'bg-red-500/5 hover:bg-red-500/10'
                        : 'hover:bg-gray-800/70'
                    )}
                  >
                    {row.getVisibleCells().map((cell) => (
                      <td key={cell.id} className="px-3 py-1.5 align-middle max-h-10 overflow-hidden">
                        {flexRender(cell.column.columnDef.cell, cell.getContext())}
                      </td>
                    ))}
                  </tr>
                )
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between text-xs text-gray-500 flex-shrink-0">
        <span>
          {rows.length > 0
            ? `Showing ${table.getState().pagination.pageIndex * table.getState().pagination.pageSize + 1}–${Math.min(
                (table.getState().pagination.pageIndex + 1) * table.getState().pagination.pageSize,
                logs.length
              )} of ${logs.length}`
            : 'No results'}
        </span>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => table.previousPage()}
            disabled={!table.getCanPreviousPage()}
            className="h-7 w-7 p-0 text-gray-500 hover:text-white hover:bg-gray-800 disabled:opacity-25"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <span className="px-2 tabular-nums">
            {table.getState().pagination.pageIndex + 1} / {Math.max(1, table.getPageCount())}
          </span>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => table.nextPage()}
            disabled={!table.getCanNextPage()}
            className="h-7 w-7 p-0 text-gray-500 hover:text-white hover:bg-gray-800 disabled:opacity-25"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}
