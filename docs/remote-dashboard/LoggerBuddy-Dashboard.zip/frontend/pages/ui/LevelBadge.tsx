import { cn } from '../../lib/shadcn/utils'

const LEVEL_STYLES: Record<string, string> = {
  INFO: 'text-sky-400 bg-sky-400/10 border border-sky-500/30',
  DEBUG: 'text-violet-400 bg-violet-400/10 border border-violet-500/30',
  WARNING: 'text-amber-400 bg-amber-400/10 border border-amber-500/30',
  ERROR: 'text-red-400 bg-red-400/10 border border-red-500/30',
}

export default function LevelBadge({ level }: { level: string | null }) {
  const resolved = level ?? 'UNKNOWN'
  const styles =
    LEVEL_STYLES[resolved] ??
    'text-gray-400 bg-gray-400/10 border border-gray-600/30'
  return (
    <span
      className={cn(
        'inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold font-mono tracking-wide',
        styles
      )}
    >
      {resolved}
    </span>
  )
}

export function CrashBadge({ isCrash }: { isCrash: boolean | null }) {
  if (!isCrash) {
    return (
      <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium text-gray-600">
        —
      </span>
    )
  }
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold text-white bg-red-600">
      💥 CRASH
    </span>
  )
}
