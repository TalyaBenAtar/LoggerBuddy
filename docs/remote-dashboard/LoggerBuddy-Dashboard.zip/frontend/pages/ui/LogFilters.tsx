import { useState } from 'react'
import { Input } from '../../lib/shadcn/input'
import { Button } from '../../lib/shadcn/button'
import { Switch } from '../../lib/shadcn/switch'
import { Label } from '../../lib/shadcn/label'
import { Popover, PopoverTrigger, PopoverContent } from '../../lib/shadcn/popover'
import { Search, X, Calendar, ChevronDown } from 'lucide-react'
import { cn } from '../../lib/shadcn/utils'

export type DatePreset = 'all' | 'today' | 'last24h' | 'last7d' | 'last30d' | 'custom'

export type FilterState = {
  search: string
  levels: string[]       // empty array = All levels
  crashesOnly: boolean
  datePreset: DatePreset
  dateFrom: string       // YYYY-MM-DD, only used when datePreset === 'custom'
  dateTo: string         // YYYY-MM-DD, only used when datePreset === 'custom'
}

type Props = {
  filters: FilterState
  onChange: (filters: FilterState) => void
}

export const LEVELS = ['INFO', 'DEBUG', 'WARNING', 'ERROR'] as const

const LEVEL_STYLES: Record<string, { dot: string; active: string; base: string }> = {
  INFO:    { dot: 'bg-sky-400',    active: 'bg-sky-500/20 border-sky-500/60 text-sky-300',    base: 'border-gray-700 text-gray-400 hover:text-sky-300 hover:border-sky-500/40' },
  DEBUG:   { dot: 'bg-violet-400', active: 'bg-violet-500/20 border-violet-500/60 text-violet-300', base: 'border-gray-700 text-gray-400 hover:text-violet-300 hover:border-violet-500/40' },
  WARNING: { dot: 'bg-amber-400',  active: 'bg-amber-500/20 border-amber-500/60 text-amber-300',  base: 'border-gray-700 text-gray-400 hover:text-amber-300 hover:border-amber-500/40' },
  ERROR:   { dot: 'bg-red-400',    active: 'bg-red-500/20 border-red-500/60 text-red-300',    base: 'border-gray-700 text-gray-400 hover:text-red-300 hover:border-red-500/40' },
}

const DATE_PRESETS: { value: DatePreset; label: string }[] = [
  { value: 'all',     label: 'All Time' },
  { value: 'today',   label: 'Today' },
  { value: 'last24h', label: 'Last 24 Hours' },
  { value: 'last7d',  label: 'Last 7 Days' },
  { value: 'last30d', label: 'Last 30 Days' },
  { value: 'custom',  label: 'Custom Range' },
]

function presetLabel(f: FilterState): string {
  if (f.datePreset === 'all') return 'Date Range'
  if (f.datePreset === 'custom') {
    if (f.dateFrom && f.dateTo) return `${f.dateFrom} → ${f.dateTo}`
    if (f.dateFrom) return `From ${f.dateFrom}`
    if (f.dateTo) return `Until ${f.dateTo}`
    return 'Custom Range'
  }
  return DATE_PRESETS.find((p) => p.value === f.datePreset)?.label ?? 'Date Range'
}

export default function LogFilters({ filters, onChange }: Props) {
  const [dateOpen, setDateOpen] = useState(false)

  const hasFilters =
    filters.search !== '' ||
    filters.levels.length > 0 ||
    filters.crashesOnly ||
    filters.datePreset !== 'all'

  function toggleLevel(level: string) {
    const already = filters.levels.includes(level)
    onChange({
      ...filters,
      levels: already
        ? filters.levels.filter((l) => l !== level)
        : [...filters.levels, level],
    })
  }

  function clearAll() {
    onChange({
      search: '',
      levels: [],
      crashesOnly: false,
      datePreset: 'all',
      dateFrom: '',
      dateTo: '',
    })
  }

  const dateActive = filters.datePreset !== 'all'

  return (
    <div className="flex flex-wrap items-center gap-2">
      {/* ── Search ──────────────────────────────────────────── */}
      <div className="relative flex-1 min-w-[220px]">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 pointer-events-none" />
        <Input
          placeholder="Search message, tag, device, session, trace..."
          value={filters.search}
          onChange={(e) => onChange({ ...filters, search: e.target.value })}
          className="pl-9 h-9 bg-gray-800 border-gray-700 text-gray-100 placeholder:text-gray-500 focus-visible:ring-blue-500/40 focus-visible:border-blue-500/60"
        />
        {filters.search && (
          <button
            onClick={() => onChange({ ...filters, search: '' })}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
            aria-label="Clear search"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* ── Level toggles (multi-select) ─────────────────────── */}
      <div className="flex items-center gap-1 bg-gray-800/60 border border-gray-700 rounded-lg px-2 py-1">
        <span className="text-[10px] font-semibold text-gray-600 uppercase tracking-widest mr-1">
          Level
        </span>
        {LEVELS.map((level) => {
          const active = filters.levels.includes(level)
          const s = LEVEL_STYLES[level]!
          return (
            <button
              key={level}
              onClick={() => toggleLevel(level)}
              className={cn(
                'flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium border transition-all',
                active ? s.active : s.base
              )}
            >
              <span className={cn('w-1.5 h-1.5 rounded-full flex-shrink-0', s.dot)} />
              {level}
            </button>
          )
        })}
      </div>

      {/* ── Crashes only toggle ──────────────────────────────── */}
      <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-gray-800 border border-gray-700">
        <Switch
          id="crashes-only"
          checked={filters.crashesOnly}
          onCheckedChange={(v) => onChange({ ...filters, crashesOnly: v })}
          className="data-[state=checked]:bg-red-600 scale-90"
        />
        <Label
          htmlFor="crashes-only"
          className="text-sm text-gray-300 cursor-pointer whitespace-nowrap"
        >
          Crashes only
        </Label>
      </div>

      {/* ── Date Range popover ──────────────────────────────── */}
      <Popover open={dateOpen} onOpenChange={setDateOpen}>
        <PopoverTrigger asChild>
          <button
            className={cn(
              'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm border transition-all whitespace-nowrap',
              dateActive
                ? 'bg-blue-500/20 border-blue-500/50 text-blue-300'
                : 'bg-gray-800 border-gray-700 text-gray-300 hover:border-gray-600 hover:text-gray-200'
            )}
          >
            <Calendar className="w-3.5 h-3.5 flex-shrink-0" />
            <span className="max-w-[160px] truncate">{presetLabel(filters)}</span>
            <ChevronDown className={cn('w-3 h-3 flex-shrink-0 transition-transform', dateOpen && 'rotate-180')} />
          </button>
        </PopoverTrigger>
        <PopoverContent
          align="start"
          className="w-72 bg-gray-900 border-gray-700 p-3 space-y-2"
        >
          <p className="text-[10px] font-semibold text-gray-500 uppercase tracking-widest mb-1">
            Date Range
          </p>

          {/* Preset buttons */}
          <div className="grid grid-cols-2 gap-1.5">
            {DATE_PRESETS.map((preset) => (
              <button
                key={preset.value}
                onClick={() => {
                  onChange({ ...filters, datePreset: preset.value })
                  if (preset.value !== 'custom') setDateOpen(false)
                }}
                className={cn(
                  'px-2.5 py-1.5 rounded-md text-xs font-medium border text-left transition-all',
                  filters.datePreset === preset.value
                    ? 'bg-blue-500/20 border-blue-500/50 text-blue-300'
                    : 'bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-750 hover:border-gray-600 hover:text-gray-200'
                )}
              >
                {preset.label}
              </button>
            ))}
          </div>

          {/* Custom date inputs */}
          {filters.datePreset === 'custom' && (
            <div className="space-y-2 pt-2 border-t border-gray-800">
              <div className="space-y-1">
                <label className="text-[10px] text-gray-500 font-medium uppercase tracking-wide">
                  From
                </label>
                <input
                  type="date"
                  value={filters.dateFrom}
                  max={filters.dateTo || undefined}
                  onChange={(e) => onChange({ ...filters, dateFrom: e.target.value })}
                  className="w-full h-8 px-2 rounded-md text-xs bg-gray-800 border border-gray-700 text-gray-200 focus:outline-none focus:border-blue-500/60 [color-scheme:dark]"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] text-gray-500 font-medium uppercase tracking-wide">
                  To
                </label>
                <input
                  type="date"
                  value={filters.dateTo}
                  min={filters.dateFrom || undefined}
                  onChange={(e) => onChange({ ...filters, dateTo: e.target.value })}
                  className="w-full h-8 px-2 rounded-md text-xs bg-gray-800 border border-gray-700 text-gray-200 focus:outline-none focus:border-blue-500/60 [color-scheme:dark]"
                />
              </div>
              <Button
                size="sm"
                onClick={() => setDateOpen(false)}
                className="w-full h-7 text-xs bg-blue-600 hover:bg-blue-700 text-white border-0"
              >
                Apply Range
              </Button>
            </div>
          )}
        </PopoverContent>
      </Popover>

      {/* ── Clear all ─────────────────────────────────────── */}
      {hasFilters && (
        <Button
          variant="ghost"
          size="sm"
          onClick={clearAll}
          className="h-9 text-gray-400 hover:text-white hover:bg-gray-800 gap-1.5 border border-gray-700"
        >
          <X className="w-3.5 h-3.5" />
          Clear Filters
        </Button>
      )}
    </div>
  )
}
