import { type ReactNode } from 'react'
import { AlertCircle, AlertTriangle, Zap, Smartphone, LayoutList } from 'lucide-react'
import type { Log } from '../types'

type Props = {
  filteredLogs: Log[]
}

type CardProps = {
  label: string
  value: number | string
  icon: ReactNode
  iconBg: string
  valueColor?: string
}

function StatCard({ label, value, icon, iconBg, valueColor = 'text-white' }: CardProps) {
  return (
    <div className="bg-gray-900 rounded-xl border border-gray-800 p-4 flex items-center gap-3.5">
      <div className={`p-2.5 rounded-lg flex-shrink-0 ${iconBg}`}>{icon}</div>
      <div className="min-w-0">
        <p className={`text-2xl font-bold leading-tight ${valueColor}`}>{value}</p>
        <p className="text-xs text-gray-500 mt-0.5 truncate">{label}</p>
      </div>
    </div>
  )
}

export default function StatsCards({ filteredLogs }: Props) {
  const errors = filteredLogs.filter((l) => l.level === 'ERROR').length
  const warnings = filteredLogs.filter((l) => l.level === 'WARNING').length
  const crashes = filteredLogs.filter((l) => l.is_crash).length
  const uniqueDevices = new Set(
    filteredLogs.map((l) => l.device_model).filter((d): d is string => Boolean(d))
  ).size

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
      <StatCard
        label="Total Logs"
        value={filteredLogs.length.toLocaleString()}
        icon={<LayoutList className="w-5 h-5 text-blue-400" />}
        iconBg="bg-blue-500/10"
      />
      <StatCard
        label="Errors"
        value={errors.toLocaleString()}
        icon={<AlertCircle className="w-5 h-5 text-red-400" />}
        iconBg="bg-red-500/10"
        valueColor={errors > 0 ? 'text-red-400' : 'text-white'}
      />
      <StatCard
        label="Warnings"
        value={warnings.toLocaleString()}
        icon={<AlertTriangle className="w-5 h-5 text-amber-400" />}
        iconBg="bg-amber-500/10"
        valueColor={warnings > 0 ? 'text-amber-400' : 'text-white'}
      />
      <StatCard
        label="Crashes"
        value={crashes.toLocaleString()}
        icon={<Zap className="w-5 h-5 text-orange-400" />}
        iconBg="bg-orange-500/10"
        valueColor={crashes > 0 ? 'text-orange-400' : 'text-white'}
      />
      <StatCard
        label="Unique Devices"
        value={uniqueDevices.toLocaleString()}
        icon={<Smartphone className="w-5 h-5 text-emerald-400" />}
        iconBg="bg-emerald-500/10"
      />
    </div>
  )
}
