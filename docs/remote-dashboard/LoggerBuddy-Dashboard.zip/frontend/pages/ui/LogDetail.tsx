import { type ReactNode } from 'react'
import { X, Clock, Tag, MessageSquare, Smartphone, Server, Package, Hash, Zap } from 'lucide-react'
import type { Log } from '../types'
import LevelBadge, { CrashBadge } from './LevelBadge'

type Props = {
  log: Log
  onClose: () => void
}

function formatTimestamp(ts: string): string {
  try {
    return new Date(ts).toLocaleString(undefined, {
      year: 'numeric',
      month: 'short',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZoneName: 'short',
    })
  } catch {
    return ts
  }
}

function Field({
  label,
  icon,
  children,
}: {
  label: string
  icon: ReactNode
  children: ReactNode
}) {
  return (
    <div className="space-y-1">
      <div className="flex items-center gap-1.5">
        <span className="text-gray-600">{icon}</span>
        <p className="text-[10px] font-semibold text-gray-500 uppercase tracking-widest">
          {label}
        </p>
      </div>
      <div className="text-sm text-gray-200 pl-5">{children}</div>
    </div>
  )
}

export default function LogDetail({ log, onClose }: Props) {
  const iconSize = 'w-3.5 h-3.5'

  return (
    <div className="bg-gray-900 rounded-xl border border-gray-800 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800 flex-shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
          <h3 className="text-sm font-semibold text-white">Log Details</h3>
          <span className="text-xs text-gray-600 font-mono">#{log.id}</span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded text-gray-500 hover:text-white hover:bg-gray-800 transition-colors"
          aria-label="Close detail panel"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <Field label="Timestamp" icon={<Clock className={iconSize} />}>
          <span className="font-mono text-xs text-gray-300">{formatTimestamp(log.timestamp)}</span>
        </Field>

        <Field label="Level" icon={<Zap className={iconSize} />}>
          <LevelBadge level={log.level} />
        </Field>

        <Field label="Tag" icon={<Tag className={iconSize} />}>
          <span className="font-mono text-sky-300 text-xs">{log.tag ?? '—'}</span>
        </Field>

        <Field label="Message" icon={<MessageSquare className={iconSize} />}>
          <p className="whitespace-pre-wrap break-words leading-relaxed text-xs text-gray-200">
            {log.message ?? '—'}
          </p>
        </Field>

        <div className="border-t border-gray-800 pt-4 space-y-4">
          <Field label="Device Model" icon={<Smartphone className={iconSize} />}>
            <span className="text-xs">{log.device_model ?? '—'}</span>
          </Field>

          <Field label="Android Version" icon={<Server className={iconSize} />}>
            <span className="text-xs">{log.android_version ? `Android ${log.android_version}` : '—'}</span>
          </Field>

          <Field label="App Version" icon={<Package className={iconSize} />}>
            <span className="text-xs">{log.app_version ?? '—'}</span>
          </Field>

          <Field label="Session ID" icon={<Hash className={iconSize} />}>
            <span className="font-mono text-[11px] text-gray-400 break-all">{log.session_id ?? '—'}</span>
          </Field>

          <Field label="Is Crash" icon={<Zap className={iconSize} />}>
            <CrashBadge isCrash={log.is_crash} />
          </Field>
        </div>

        <div className="border-t border-gray-800 pt-4">
          <div className="flex items-center gap-1.5 mb-2">
            <p className="text-[10px] font-semibold text-gray-500 uppercase tracking-widest">
              Stack Trace
            </p>
          </div>
          {log.stack_trace ? (
            <div className="bg-[#0d1117] rounded-lg border border-gray-800 overflow-auto max-h-60">
              <pre className="p-3 text-[11px] font-mono text-red-300 whitespace-pre leading-relaxed">
                {log.stack_trace}
              </pre>
            </div>
          ) : (
            <p className="text-xs text-gray-600 italic pl-0">No stack trace available.</p>
          )}
        </div>
      </div>
    </div>
  )
}
