import { useMemo, type ReactNode } from 'react'
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  BarChart,
  Bar,
} from 'recharts'
import type { Log } from '../types'

type Props = {
  logs: Log[]
}

const LEVEL_COLORS: Record<string, string> = {
  INFO: '#38bdf8',
  DEBUG: '#a78bfa',
  WARNING: '#fbbf24',
  ERROR: '#f87171',
  UNKNOWN: '#6b7280',
}

const DEVICE_PALETTE = [
  '#60a5fa', '#34d399', '#f472b6', '#fb923c', '#a78bfa',
  '#38bdf8', '#4ade80', '#facc15', '#f87171', '#818cf8',
]

const TOOLTIP_STYLE = {
  backgroundColor: '#1f2937',
  border: '1px solid #374151',
  borderRadius: '8px',
  color: '#e5e7eb',
  fontSize: '12px',
  boxShadow: '0 4px 12px rgba(0,0,0,0.4)',
}

const AXIS_TICK_STYLE = { fill: '#4b5563', fontSize: 10 }
const GRID_COLOR = '#1f2937'

function ChartCard({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
      <p className="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-4">{title}</p>
      {children}
    </div>
  )
}

export default function LogCharts({ logs }: Props) {
  // Donut: by level
  const levelData = useMemo(() => {
    const counts: Record<string, number> = {}
    for (const l of logs) {
      const key = l.level ?? 'UNKNOWN'
      counts[key] = (counts[key] ?? 0) + 1
    }
    return Object.entries(counts).map(([name, value]) => ({ name, value }))
  }, [logs])

  // Line: over time (grouped by hour)
  const timeData = useMemo(() => {
    const counts: Record<string, number> = {}
    for (const l of logs) {
      const d = new Date(l.timestamp)
      const key = `${String(d.getMonth() + 1).padStart(2, '0')}/${String(
        d.getDate()
      ).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:00`
      counts[key] = (counts[key] ?? 0) + 1
    }
    return Object.entries(counts)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([time, count]) => ({ time, count }))
  }, [logs])

  // Bar: by device
  const deviceData = useMemo(() => {
    const counts: Record<string, number> = {}
    for (const l of logs) {
      const key = l.device_model ?? 'Unknown'
      counts[key] = (counts[key] ?? 0) + 1
    }
    return Object.entries(counts)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 10)
      .map(([device, count]) => ({ device, count }))
  }, [logs])

  if (logs.length === 0) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {['Logs by Level', 'Logs Over Time', 'Logs by Device'].map((t) => (
          <ChartCard key={t} title={t}>
            <div className="h-52 flex items-center justify-center text-gray-700 text-sm">
              No data
            </div>
          </ChartCard>
        ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      {/* Donut: Logs by Level */}
      <ChartCard title="Logs by Level">
        <ResponsiveContainer width="100%" height={210}>
          <PieChart>
            <Pie
              data={levelData}
              cx="50%"
              cy="50%"
              innerRadius={52}
              outerRadius={80}
              paddingAngle={3}
              dataKey="value"
              strokeWidth={0}
            >
              {levelData.map((entry, i) => (
                <Cell
                  key={entry.name}
                  fill={LEVEL_COLORS[entry.name] ?? DEVICE_PALETTE[i % DEVICE_PALETTE.length] ?? '#6b7280'}
                />
              ))}
            </Pie>
            <Tooltip contentStyle={TOOLTIP_STYLE} />
            <Legend
              iconSize={8}
              formatter={(value: string) => (
                <span style={{ color: '#9ca3af', fontSize: 11 }}>{value}</span>
              )}
            />
          </PieChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* Line: Logs Over Time */}
      <ChartCard title="Logs Over Time">
        <ResponsiveContainer width="100%" height={210}>
          <LineChart data={timeData} margin={{ top: 4, right: 8, left: -24, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke={GRID_COLOR} vertical={false} />
            <XAxis
              dataKey="time"
              tick={AXIS_TICK_STYLE}
              tickLine={false}
              axisLine={{ stroke: '#374151' }}
              interval="preserveStartEnd"
            />
            <YAxis
              tick={AXIS_TICK_STYLE}
              tickLine={false}
              axisLine={{ stroke: '#374151' }}
              allowDecimals={false}
            />
            <Tooltip contentStyle={TOOLTIP_STYLE} />
            <Line
              type="monotone"
              dataKey="count"
              name="Logs"
              stroke="#60a5fa"
              strokeWidth={2}
              dot={{ r: 3, fill: '#60a5fa', strokeWidth: 0 }}
              activeDot={{ r: 5, fill: '#93c5fd', strokeWidth: 0 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* Bar: Logs by Device */}
      <ChartCard title="Logs by Device">
        <ResponsiveContainer width="100%" height={210}>
          <BarChart data={deviceData} margin={{ top: 4, right: 8, left: -24, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke={GRID_COLOR} vertical={false} />
            <XAxis
              dataKey="device"
              tick={{ fill: '#4b5563', fontSize: 9 }}
              tickLine={false}
              axisLine={{ stroke: '#374151' }}
            />
            <YAxis
              tick={AXIS_TICK_STYLE}
              tickLine={false}
              axisLine={{ stroke: '#374151' }}
              allowDecimals={false}
            />
            <Tooltip contentStyle={TOOLTIP_STYLE} />
            <Bar dataKey="count" name="Logs" radius={[4, 4, 0, 0]}>
              {deviceData.map((_, i) => (
                <Cell
                  key={`cell-${i}`}
                  fill={DEVICE_PALETTE[i % DEVICE_PALETTE.length] ?? '#60a5fa'}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  )
}
