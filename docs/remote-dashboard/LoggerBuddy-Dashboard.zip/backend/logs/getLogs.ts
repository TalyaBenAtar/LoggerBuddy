type Log = {
  id: number
  timestamp: string
  level: string | null
  tag: string | null
  message: string | null
  is_crash: boolean | null
  stack_trace: string | null
  device_model: string | null
  android_version: string | null
  app_version: string | null
  session_id: string | null
}

export default async function () {
  const result = await retoolDb.query<Log>(
    'SELECT * FROM logs ORDER BY timestamp DESC'
  )
  return result.data
}
