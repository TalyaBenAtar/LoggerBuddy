export default async function () {
  const result = await retoolDb.query('DELETE FROM logs')
  return result.data
}
