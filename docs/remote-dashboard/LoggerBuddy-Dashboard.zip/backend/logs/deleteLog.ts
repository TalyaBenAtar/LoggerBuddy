type Params = {
  id: number
}

export default async function (req: { params: Params; user: User }) {
  const result = await retoolDb.query(
    'DELETE FROM logs WHERE id = $1',
    [req.params.id]
  )
  return result.data
}
